# Network Test Tool
C# Winform tool to test Net Performance using TCP/UDP/Ping.
Using ConfigData.XML to change IP Address 
