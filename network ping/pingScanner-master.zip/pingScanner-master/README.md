# Ping Scanner
A simple Network scanner written in C#, using Visual Studio.

![alt tag](https://github.com/mirkoBastianini/pingScanner/blob/master/image/image.png)
